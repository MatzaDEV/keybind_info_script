local showPanel = false
local wasPauseMenuActive = false

RegisterCommand("toggleKeybindInfo", function()
    showPanel = not showPanel
    SetNuiFocus(false, false)
    SendNUIMessage({
        action = "toggle",
        state = showPanel
    })
end, false)

RegisterKeyMapping("toggleKeybindInfo", "Toggle Keybind Info Panel", "keyboard", "F2")

-- Pause menu aktifken paneli gizle
Citizen.CreateThread(function()
    while true do
        Citizen.Wait(200)
        local pauseActive = IsPauseMenuActive()

        if pauseActive ~= wasPauseMenuActive then
            wasPauseMenuActive = pauseActive

            if pauseActive then
                SendNUIMessage({ action = "hidePanel" })
            elseif showPanel then
                SendNUIMessage({ action = "showPanel" })
            end
        end
    end
end)
