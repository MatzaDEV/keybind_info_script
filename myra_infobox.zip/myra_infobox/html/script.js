window.addEventListener('message', function (event) {
  const panel = document.getElementById("keybind-panel");

  if (event.data.action === "toggle") {
    panel.style.display = event.data.state ? "flex" : "none";
  }

  if (event.data.action === "hidePanel") {
    panel.style.display = "none";
  }

  if (event.data.action === "showPanel") {
    panel.style.display = "flex";
  }
});
